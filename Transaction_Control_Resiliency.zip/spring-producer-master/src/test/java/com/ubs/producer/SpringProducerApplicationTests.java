package com.ubs.producer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
