package com.ubs.consumer.service;

public interface RePublishService {
    void repost();
}
