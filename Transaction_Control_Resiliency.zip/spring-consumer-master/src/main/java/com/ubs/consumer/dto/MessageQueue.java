package com.ubs.consumer.dto;

public class MessageQueue {
    private String text;

    public MessageQueue() {
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
