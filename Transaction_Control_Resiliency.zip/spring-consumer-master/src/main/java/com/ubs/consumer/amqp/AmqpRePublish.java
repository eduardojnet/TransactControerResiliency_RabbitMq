package com.ubs.consumer.amqp;

public interface AmqpRePublish {
    void rePublish();
}
