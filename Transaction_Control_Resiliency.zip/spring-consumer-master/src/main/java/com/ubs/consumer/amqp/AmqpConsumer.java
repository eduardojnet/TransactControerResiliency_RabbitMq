package com.ubs.consumer.amqp;

public interface AmqpConsumer<T> {
    void consumer(T t);
}
